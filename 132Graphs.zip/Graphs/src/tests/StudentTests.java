package tests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import implementation.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
	@Test
    public void DFS() {
        Graph<Double> graph = createGraph();
        StringBuffer results = new StringBuffer();
        PrintCallBack<Double> printCallBack = new PrintCallBack<Double>();

        graph.doDepthFirstSearch("D", printCallBack);
        results.append(printCallBack.getResult());
        System.out.println(results);
    }
private Graph<Double> createGraph() {
        Graph<Double> graph = new Graph<Double>();

        /* Adding vertices to the graph /
        String[] vertices = new String[] { "A", "B", "C", "D", "E","F", "M", "W", "X" };
        for (int i = 0; i < vertices.length; i++) {
            graph.addVertex(vertices[i], i + 1000.50);
        }

        / Adding directed edges */
        graph.addDirectedEdge("A", "C", 1);
        graph.addDirectedEdge("A", "X", 1);
        graph.addDirectedEdge("A", "B", 2);
        graph.addDirectedEdge("B", "W", 2);
        graph.addDirectedEdge("A", "D", 1);
        graph.addDirectedEdge("D", "E", 2);
        graph.addDirectedEdge("D", "B", 2);
        graph.addDirectedEdge("C", "E", 2);
        graph.addDirectedEdge("C", "B", 2);
        graph.addDirectedEdge("E", "A", 2);
        graph.addDirectedEdge("F", "A", 2);
        graph.addDirectedEdge("D", "M", 2);

        return graph;
    }

    private static String runDijkstras(Graph<Double> graph, String startVertex) {
        ArrayList<String> shortestPath = new ArrayList<String>();
        StringBuffer results = new StringBuffer();
        Set<String> vertices = graph.getVertices();
        TreeSet<String> sortedVertices = new TreeSet<String>(vertices);

        for (String endVertex : sortedVertices) {
            int shortestPathCost = graph.doDijkstras(startVertex, endVertex, shortestPath);
            results.append("Shortest path cost between " + startVertex + " " + endVertex + ": " + shortestPathCost);
            results.append(", Path: " + shortestPath + "\n");
            shortestPath.clear();
        }

        return results.toString();
    }
}